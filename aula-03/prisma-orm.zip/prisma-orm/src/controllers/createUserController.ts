import { Request, Response } from "express";
import { prismaClient } from "../database/prismaClient";

export class CreateUserController {
  async handle(request: Request, response: Response) {
    const { ,  } = request.body;

    const product = await prismaClient.product.create({
      data: {
        ,
        ,
        ,
      },
    });

    return response.json(product);
  }
}