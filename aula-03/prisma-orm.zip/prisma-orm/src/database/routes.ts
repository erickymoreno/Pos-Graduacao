import {Router} from "express";
import { CreateUserController } from "../controllers/createUserController";


const router = Router();

const createUser = new CreateUserController();


router.post("/user", createUser.handle);


export { router };